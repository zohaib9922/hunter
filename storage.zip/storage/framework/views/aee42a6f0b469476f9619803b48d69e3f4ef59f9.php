<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">
    <head>        
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="/images/cropped-favicon-32x32.png" sizes="32x32" />

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">

        <title><?php echo e(config('app.name', 'My Hunter'), false); ?></title>

        <!-- Styles -->
        <link href="<?php echo e(asset('css/bootstrap.min.css'), false); ?>?v=1.0" rel="stylesheet"> 
        <link href="<?php echo e(asset('css/styles.css'), false); ?>?v=1.0" rel="stylesheet"> 

        <?php if (App::environment('local')) { ?>
            <meta name="robots" content="noindex">
            <meta name="googlebot" content="noindex">
        <?php } ?>

        <?php if (App::environment('production')) { ?>
            <!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-154576303-1"></script>
            <script>
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());

                gtag('config', 'UA-154576303-1');
            </script>
        <?php } ?>

        <?php echo $__env->yieldContent('cssContent'); ?>
          
    </head>
    <body>
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="site-content-contain">
                    <?php echo $__env->yieldContent('content'); ?>
            </div>
            
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>

    <script src="/js/jquery-3.4.1.min.js"></script>
    <script src="/js/jquery.validate.min.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
   
    
    <script>
        $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });
        <?php $__env->startSection('jsContent'); ?>

   $(document).ready(function() { 
      $(".mobile-menu").click(function() { 
         $(".main-navigation").slideToggle("slow"); 
      }); 
   });  
   $(document).ready(function() { 
      $(".mobile-profile-menu").click(function() { 
         $(".user-left-menu").slideToggle("slow"); 
      }); 
   });  


    </script>
    
    
    <?php echo $__env->yieldContent('jsContent'); ?>

</html>
<?php /**PATH /Volumes/beta/workspace/natural-shop/resources/views/layouts/master.blade.php ENDPATH**/ ?>